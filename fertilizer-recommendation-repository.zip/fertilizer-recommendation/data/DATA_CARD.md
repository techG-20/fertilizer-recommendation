# Demo dataset

`demo_fertilizer.csv` is synthetically generated for software testing and demonstration.
It is **not** a real agronomic dataset and must not be used for field fertilizer decisions.

For a real project, replace it with a properly licensed, representative dataset and
evaluate it using a held-out test set and field/domain validation.
