from src.recommender import recommend_rule_based, nutrient_gaps


def test_nutrient_gaps():
    gaps = nutrient_gaps(10, 10, 10)
    assert gaps["Nitrogen"] == 15
    assert gaps["Phosphorous"] == 10
    assert gaps["Potassium"] == 5


def test_recommendation_returns_known_fertilizer():
    values = {
        "Temperature": 28, "Humidity": 65, "Moisture": 45,
        "Soil Type": "Loamy", "Crop Type": "Maize",
        "Nitrogen": 8, "Phosphorous": 12, "Potassium": 8,
    }
    result = recommend_rule_based(values)
    assert result.fertilizer in {
        "Urea", "DAP", "14-35-14", "28-28",
        "17-17-17", "20-20", "10-26-26"
    }
    assert 0 <= result.score <= 1


def test_invalid_input():
    values = {
        "Temperature": 28, "Humidity": 65, "Moisture": 45,
        "Soil Type": "Loamy", "Crop Type": "Maize",
        "Nitrogen": 999, "Phosphorous": 12, "Potassium": 8,
    }
    try:
        recommend_rule_based(values)
        assert False
    except ValueError:
        assert True
