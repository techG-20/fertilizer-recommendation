from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

FERTILIZERS: Dict[str, Tuple[float, float, float]] = {
    "Urea": (46, 0, 0),
    "DAP": (18, 46, 0),
    "14-35-14": (14, 35, 14),
    "28-28": (28, 28, 0),
    "17-17-17": (17, 17, 17),
    "20-20": (20, 20, 0),
    "10-26-26": (10, 26, 26),
}

REFERENCE_NPK = {"Nitrogen": 25, "Phosphorous": 20, "Potassium": 15}


@dataclass
class Recommendation:
    fertilizer: str
    score: float
    explanation: str
    deficiencies: List[str]
    composition: Tuple[float, float, float]


def validate_inputs(values: dict) -> None:
    ranges = {
        "Nitrogen": (0, 200),
        "Phosphorous": (0, 200),
        "Potassium": (0, 200),
        "Temperature": (-10, 60),
        "Humidity": (0, 100),
        "Moisture": (0, 100),
    }
    for key, (low, high) in ranges.items():
        value = float(values[key])
        if not low <= value <= high:
            raise ValueError(f"{key} must be between {low} and {high}.")


def nutrient_gaps(n: float, p: float, k: float) -> dict:
    return {
        "Nitrogen": max(0.0, REFERENCE_NPK["Nitrogen"] - n),
        "Phosphorous": max(0.0, REFERENCE_NPK["Phosphorous"] - p),
        "Potassium": max(0.0, REFERENCE_NPK["Potassium"] - k),
    }


def _fertilizer_score(gaps: dict, composition: Tuple[float, float, float]) -> float:
    comp = list(composition)
    target = [gaps["Nitrogen"], gaps["Phosphorous"], gaps["Potassium"]]
    if sum(target) == 0:
        return 0.5

    target_norm = [x / sum(target) for x in target]
    comp_norm = [x / sum(comp) for x in comp]
    distance = sum(abs(a - b) for a, b in zip(target_norm, comp_norm))
    score = max(0.0, 1.0 - distance / 2.0)

    dominant = max(range(3), key=lambda i: target[i])
    if target[dominant] > 0 and comp[dominant] == 0:
        score *= 0.35
    return score


def recommend_rule_based(values: dict) -> Recommendation:
    validate_inputs(values)
    gaps = nutrient_gaps(
        float(values["Nitrogen"]),
        float(values["Phosphorous"]),
        float(values["Potassium"]),
    )
    deficiencies = [name for name, gap in gaps.items() if gap > 0]

    ranked = sorted(
        (
            (_fertilizer_score(gaps, composition), name, composition)
            for name, composition in FERTILIZERS.items()
        ),
        reverse=True,
    )
    score, fertilizer, composition = ranked[0]

    if deficiencies:
        explanation = (
            f"The largest software-detected nutrient gaps are {', '.join(deficiencies)}. "
            f"{fertilizer} was selected because its N-P-K profile is comparatively aligned "
            f"with that deficiency pattern."
        )
    else:
        explanation = (
            "The supplied N-P-K values are above the broad demo reference bands. "
            "Confirm the result with a soil test before adding fertilizer."
        )

    return Recommendation(
        fertilizer=fertilizer,
        score=round(score, 4),
        explanation=explanation,
        deficiencies=deficiencies,
        composition=composition,
    )


def fertilizer_candidates(values: dict, top_k: int = 3) -> List[Recommendation]:
    validate_inputs(values)
    gaps = nutrient_gaps(
        float(values["Nitrogen"]),
        float(values["Phosphorous"]),
        float(values["Potassium"]),
    )
    deficiencies = [name for name, gap in gaps.items() if gap > 0]

    ranked = sorted(
        (
            (_fertilizer_score(gaps, composition), name, composition)
            for name, composition in FERTILIZERS.items()
        ),
        reverse=True,
    )
    return [
        Recommendation(
            fertilizer=name,
            score=round(score, 4),
            explanation=f"Ranked against nutrient-gap profile: {', '.join(deficiencies) or 'no detected deficit'}.",
            deficiencies=deficiencies,
            composition=composition,
        )
        for score, name, composition in ranked[:top_k]
    ]
