from pathlib import Path
import json

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "demo_fertilizer.csv"
MODEL_DIR = ROOT / "models"
MODEL_DIR.mkdir(exist_ok=True)

FEATURES = [
    "Temperature", "Humidity", "Moisture", "Soil Type", "Crop Type",
    "Nitrogen", "Phosphorous", "Potassium"
]
TARGET = "Fertilizer Name"


def main() -> None:
    df = pd.read_csv(DATA_PATH)
    X, y = df[FEATURES], df[TARGET]

    categorical = ["Soil Type", "Crop Type"]
    numerical = [c for c in FEATURES if c not in categorical]

    preprocessor = ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical),
        ("num", "passthrough", numerical),
    ])

    model = RandomForestClassifier(
        n_estimators=300,
        max_depth=18,
        min_samples_leaf=1,
        random_state=42,
        class_weight="balanced",
    )

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    X_train_t = preprocessor.fit_transform(X_train)
    X_test_t = preprocessor.transform(X_test)

    model.fit(X_train_t, y_train)
    predictions = model.predict(X_test_t)
    accuracy = accuracy_score(y_test, predictions)

    joblib.dump(
        {"preprocessor": preprocessor, "model": model, "features": FEATURES},
        MODEL_DIR / "fertilizer_model.joblib",
    )

    metrics = {
        "accuracy": accuracy,
        "classification_report": classification_report(
            y_test, predictions, output_dict=True, zero_division=0
        ),
        "warning": "Demo dataset metrics are not evidence of real-world agronomic accuracy.",
    }
    (MODEL_DIR / "metrics.json").write_text(json.dumps(metrics, indent=2))
    print(f"Saved model. Demo test accuracy: {accuracy:.3f}")


if __name__ == "__main__":
    main()
